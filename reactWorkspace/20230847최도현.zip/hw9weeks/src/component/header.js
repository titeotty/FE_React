function Header(){
    return(
      <div>
        <h1>헤더 영역  </h1>
      </div>
    );
  }

  export default Header;